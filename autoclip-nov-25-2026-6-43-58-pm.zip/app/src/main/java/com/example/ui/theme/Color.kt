package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cinema Studio Dark Palette
val StudioObsidian = Color(0xFF0A0D14)
val StudioSurface = Color(0xFF121722)
val StudioSurfaceElevated = Color(0xFF1A2130)
val StudioSurfaceHighest = Color(0xFF232C3F)
val StudioOutline = Color(0xFF2D374E)

val CoralFlame = Color(0xFFFF6342)
val CoralFlameContainer = Color(0xFF4B1A10)
val OnCoralFlame = Color(0xFFFFFFFF)

val ElectricCyan = Color(0xFF22D3EE)
val ElectricCyanContainer = Color(0xFF0B3742)
val OnElectricCyan = Color(0xFF041F26)

val AmberGold = Color(0xFFFBBF24)
val AmberGoldContainer = Color(0xFF3E2D08)

val MintSuccess = Color(0xFF34D399)
val RoseError = Color(0xFFFB7185)
val RoseErrorContainer = Color(0xFF4C1120)

val TextPrimaryDark = Color(0xFFF3F6FC)
val TextSecondaryDark = Color(0xFF9BA8C2)

// Studio Light Palette
val LightCanvas = Color(0xFFF6F7FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEAEEF6)
val LightOutline = Color(0xFFD0D8E8)
val CoralFlameDeep = Color(0xFFD94425)
val CyanDeep = Color(0xFF0891B2)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
