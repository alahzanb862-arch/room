package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MovieFilter
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.outlined.MovieFilter
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.data.model.RenderJobState
import com.example.ui.components.AutoPlanPreviewCard
import com.example.ui.components.MediaSelectionSection
import com.example.ui.components.PromptComposerCard
import com.example.ui.components.RenderProgressCard
import com.example.ui.components.SavedExportsSection
import com.example.ui.components.VideoPreviewCard
import com.example.ui.viewmodel.StudioUiState
import com.example.ui.viewmodel.StudioViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioScreen(
    viewModel: StudioViewModel = viewModel()
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val savedVideos by viewModel.savedVideos.collectAsStateWithLifecycle()
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    // Zero-permission Android Photo Picker for multiple images & videos
    val mediaPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 25),
        onResult = { uris ->
            viewModel.onMediaPicked(uris)
        }
    )

    // Zero-permission SAF document picker for optional background music
    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri ->
            viewModel.onBackgroundAudioPicked(uri)
        }
    )

    // Runtime notification permission for background export progress bar (Android 13+)
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = {
            // Proceed regardless so user is never blocked even if notifications are declined
            viewModel.startAutoCreation()
        }
    )

    val startCreationWithPermission: () -> Unit = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            viewModel.startAutoCreation()
        }
    }

    // Handle system Back cleanly when previewing a saved video or viewing the Library tab
    BackHandler(enabled = uiState.activePreviewVideoUri != null || selectedTab != 0) {
        if (uiState.activePreviewVideoUri != null) {
            viewModel.openVideoPreview(null)
        } else {
            selectedTab = 0
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isExpandedWidth = maxWidth >= 840.dp

        Scaffold(
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Surface(
                                shape = MaterialTheme.shapes.small,
                                color = MaterialTheme.colorScheme.secondaryContainer
                            ) {
                                Text(
                                    text = "FFmpeg Offline",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background
                    )
                )
            },
            bottomBar = {
                if (!isExpandedWidth) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.navigationBarsPadding()
                    ) {
                        NavigationBarItem(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            icon = {
                                Icon(
                                    imageVector = if (selectedTab == 0) Icons.Filled.MovieFilter else Icons.Outlined.MovieFilter,
                                    contentDescription = stringResource(R.string.tab_create)
                                )
                            },
                            label = { Text(stringResource(R.string.tab_create)) },
                            modifier = Modifier.testTag("nav_tab_create")
                        )
                        NavigationBarItem(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            icon = {
                                Icon(
                                    imageVector = if (selectedTab == 1) Icons.Filled.VideoLibrary else Icons.Outlined.VideoLibrary,
                                    contentDescription = stringResource(R.string.tab_library)
                                )
                            },
                            label = { Text("${stringResource(R.string.tab_library)} (${savedVideos.size})") },
                            modifier = Modifier.testTag("nav_tab_library")
                        )
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (isExpandedWidth) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Spacer(Modifier.height(16.dp))
                        NavigationRailItem(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            icon = {
                                Icon(
                                    imageVector = if (selectedTab == 0) Icons.Filled.MovieFilter else Icons.Outlined.MovieFilter,
                                    contentDescription = stringResource(R.string.tab_create)
                                )
                            },
                            label = { Text(stringResource(R.string.tab_create)) }
                        )
                        NavigationRailItem(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            icon = {
                                Icon(
                                    imageVector = if (selectedTab == 1) Icons.Filled.VideoLibrary else Icons.Outlined.VideoLibrary,
                                    contentDescription = stringResource(R.string.tab_library)
                                )
                            },
                            label = { Text(stringResource(R.string.tab_library)) }
                        )
                    }
                }

                Box(
                    contentAlignment = Alignment.TopCenter,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp)
                ) {
                    if (selectedTab == 0) {
                        CreateStudioContent(
                            uiState = uiState,
                            isTwoColumn = isExpandedWidth,
                            onPickMedia = {
                                mediaPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                                )
                            },
                            onRemoveAsset = viewModel::removeAsset,
                            onClearMedia = viewModel::clearAllAssets,
                            onPromptChanged = viewModel::onPromptChanged,
                            onAspectSelected = viewModel::onAspectPresetSelected,
                            onPickAudio = { audioPickerLauncher.launch(arrayOf("audio/*")) },
                            onClearAudio = viewModel::clearBackgroundAudio,
                            onStartCreate = {
                                if (uiState.selectedAssets.isEmpty()) {
                                    coroutineScope.launch {
                                        snackbarHostState.showSnackbar("أضف صورة أو فيديو واحداً على الأقل للبدء")
                                    }
                                } else {
                                    startCreationWithPermission()
                                }
                            },
                            onCancelRender = viewModel::cancelActiveExport,
                            onShareVideo = { uri -> shareVideoUri(context, uri) },
                            onNewProject = {
                                viewModel.resetRenderState()
                                viewModel.clearAllAssets()
                                viewModel.onPromptChanged("")
                            }
                        )
                    } else {
                        Column(
                            modifier = Modifier
                                .widthIn(max = 720.dp)
                                .fillMaxSize()
                                .padding(top = 8.dp, bottom = 16.dp)
                        ) {
                            uiState.activePreviewVideoUri?.let { previewUri ->
                                val matching = savedVideos.firstOrNull { it.uriString == previewUri }
                                VideoPreviewCard(
                                    videoUriString = previewUri,
                                    fileName = matching?.displayName ?: "AutoClip.mp4",
                                    aspectLabel = matching?.aspectLabel ?: "9:16",
                                    fileSizeBytes = matching?.sizeBytes ?: 0L,
                                    onShareClick = { shareVideoUri(context, it) },
                                    onNewProjectClick = { viewModel.openVideoPreview(null) }
                                )
                                Spacer(Modifier.height(14.dp))
                            }

                            SavedExportsSection(
                                videos = savedVideos,
                                onPlayClick = { item -> viewModel.openVideoPreview(item.uriString) },
                                onShareClick = { item -> shareVideoUri(context, item.uriString) },
                                onDeleteClick = { item -> viewModel.deleteSavedHistoryItem(item.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CreateStudioContent(
    uiState: StudioUiState,
    isTwoColumn: Boolean,
    onPickMedia: () -> Unit,
    onRemoveAsset: (String) -> Unit,
    onClearMedia: () -> Unit,
    onPromptChanged: (String) -> Unit,
    onAspectSelected: (com.example.data.model.AspectRatioPreset) -> Unit,
    onPickAudio: () -> Unit,
    onClearAudio: () -> Unit,
    onStartCreate: () -> Unit,
    onCancelRender: () -> Unit,
    onShareVideo: (String) -> Unit,
    onNewProject: () -> Unit
) {
    val scrollState = rememberScrollState()

    if (isTwoColumn) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier
                .widthIn(max = 1080.dp)
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(vertical = 12.dp)
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.weight(1f)
            ) {
                MediaSelectionSection(
                    assets = uiState.selectedAssets,
                    isInspecting = uiState.isInspectingMedia,
                    onPickMediaClick = onPickMedia,
                    onRemoveAsset = onRemoveAsset,
                    onClearAll = onClearMedia
                )
                PromptComposerCard(
                    promptText = uiState.promptText,
                    selectedAspect = uiState.selectedAspectOverride,
                    audioDisplayName = uiState.audioDisplayName,
                    onPromptChange = onPromptChanged,
                    onAspectSelect = onAspectSelected,
                    onPickAudioClick = onPickAudio,
                    onClearAudioClick = onClearAudio
                )
            }

            Column(
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.weight(1f)
            ) {
                StudioExecutionColumn(
                    uiState = uiState,
                    onStartCreate = onStartCreate,
                    onCancelRender = onCancelRender,
                    onShareVideo = onShareVideo,
                    onNewProject = onNewProject
                )
            }
        }
    } else {
        Column(
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(top = 8.dp, bottom = 24.dp)
        ) {
            MediaSelectionSection(
                assets = uiState.selectedAssets,
                isInspecting = uiState.isInspectingMedia,
                onPickMediaClick = onPickMedia,
                onRemoveAsset = onRemoveAsset,
                onClearAll = onClearMedia
            )

            PromptComposerCard(
                promptText = uiState.promptText,
                selectedAspect = uiState.selectedAspectOverride,
                audioDisplayName = uiState.audioDisplayName,
                onPromptChange = onPromptChanged,
                onAspectSelect = onAspectSelected,
                onPickAudioClick = onPickAudio,
                onClearAudioClick = onClearAudio
            )

            StudioExecutionColumn(
                uiState = uiState,
                onStartCreate = onStartCreate,
                onCancelRender = onCancelRender,
                onShareVideo = onShareVideo,
                onNewProject = onNewProject
            )
        }
    }
}

@Composable
private fun StudioExecutionColumn(
    uiState: StudioUiState,
    onStartCreate: () -> Unit,
    onCancelRender: () -> Unit,
    onShareVideo: (String) -> Unit,
    onNewProject: () -> Unit
) {
    AnimatedVisibility(visible = uiState.currentPlan != null && uiState.renderState is RenderJobState.Idle) {
        uiState.currentPlan?.let { plan ->
            AutoPlanPreviewCard(plan = plan)
        }
    }

    when (val state = uiState.renderState) {
        is RenderJobState.Idle -> {
            Button(
                onClick = onStartCreate,
                enabled = !uiState.isInspectingMedia,
                shape = MaterialTheme.shapes.large,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (uiState.selectedAssets.isNotEmpty()) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant
                    },
                    contentColor = if (uiState.selectedAssets.isNotEmpty()) {
                        MaterialTheme.colorScheme.onPrimary
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    }
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .minimumInteractiveComponentSize()
                    .testTag("create_video_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.AutoAwesome,
                    contentDescription = null,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = stringResource(R.string.create_video_cta),
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }
        is RenderJobState.Running -> {
            RenderProgressCard(
                state = state,
                onCancelClick = onCancelRender
            )
        }
        is RenderJobState.Completed -> {
            VideoPreviewCard(
                videoUriString = state.outputUriString,
                fileName = state.fileName,
                aspectLabel = state.aspectLabel,
                fileSizeBytes = state.fileSizeBytes,
                onShareClick = onShareVideo,
                onNewProjectClick = onNewProject
            )
        }
        is RenderJobState.Failed -> {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "تعذر إكمال عملية الدمج",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = state.message,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = onStartCreate,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .minimumInteractiveComponentSize()
                            .testTag("retry_render_button")
                    ) {
                        Text("إعادة المحاولة")
                    }
                }
            }
        }
    }

    // Subtle free offline guarantee footer
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.7f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = "يعمل محلياً بالكامل على جهازك عبر FFmpeg • مجاني 100% بدون اشتراكات أو خوادم مدفوعة",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
        )
    }
}

private fun shareVideoUri(context: Context, uriString: String) {
    if (uriString.isBlank()) return
    val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = "video/mp4"
        putExtra(Intent.EXTRA_STREAM, Uri.parse(uriString))
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(shareIntent, context.getString(R.string.share_video_cta)))
}
