package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.example.data.model.AutoRenderPlan
import java.util.Locale

@Composable
fun AutoPlanPreviewCard(
    plan: AutoRenderPlan,
    modifier: Modifier = Modifier
) {
    val totalSec = (plan.estimatedDurationMs / 1000.0)
    val durationFormatted = String.format(Locale.US, "%.1fs", totalSec)

    Card(
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.35f)),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "خطة المونتاج التلقائية",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Surface(
                    shape = MaterialTheme.shapes.small,
                    color = MaterialTheme.colorScheme.secondaryContainer
                ) {
                    Text(
                        text = "${plan.resolvedAspectRatio.ratioLabel} • ~$durationFormatted",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            PlanSpecRow(
                icon = Icons.Filled.Crop,
                title = "توحيد الأبعاد",
                value = "${plan.resolvedAspectRatio.targetWidth}×${plan.resolvedAspectRatio.targetHeight} (ملء الشاشة بدون حواف)"
            )
            PlanSpecRow(
                icon = Icons.Filled.FormatListNumbered,
                title = "الترتيب التلقائي",
                value = plan.orderingStrategy.labelAr
            )
            PlanSpecRow(
                icon = Icons.Filled.ColorLens,
                title = "الفلتر والهوية البصرية",
                value = plan.stylePreset.labelAr
            )
            PlanSpecRow(
                icon = Icons.Filled.Timer,
                title = "إيقاع الصور",
                value = "${String.format(Locale.US, "%.1f", plan.photoDurationMs / 1000.0)} ثانية لكل صورة"
            )
            PlanSpecRow(
                icon = Icons.Filled.Subtitles,
                title = "العنوان الافتتاحي",
                value = plan.openingTitle
            )
        }
    }
}

@Composable
private fun PlanSpecRow(
    icon: ImageVector,
    title: String,
    value: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.size(16.dp)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = "$title:",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.width(6.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
    }
}
