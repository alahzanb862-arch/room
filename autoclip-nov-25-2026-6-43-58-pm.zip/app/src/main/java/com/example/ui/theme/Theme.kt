package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val DarkColorScheme = darkColorScheme(
    primary = CoralFlame,
    onPrimary = OnCoralFlame,
    primaryContainer = CoralFlameContainer,
    onPrimaryContainer = TextPrimaryDark,
    secondary = ElectricCyan,
    onSecondary = OnElectricCyan,
    secondaryContainer = ElectricCyanContainer,
    onSecondaryContainer = TextPrimaryDark,
    tertiary = AmberGold,
    onTertiary = StudioObsidian,
    tertiaryContainer = AmberGoldContainer,
    onTertiaryContainer = TextPrimaryDark,
    background = StudioObsidian,
    onBackground = TextPrimaryDark,
    surface = StudioSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = StudioSurfaceElevated,
    onSurfaceVariant = TextSecondaryDark,
    surfaceContainerHigh = StudioSurfaceElevated,
    surfaceContainerHighest = StudioSurfaceHighest,
    outline = StudioOutline,
    error = RoseError,
    errorContainer = RoseErrorContainer,
    onErrorContainer = TextPrimaryDark
)

private val LightColorScheme = lightColorScheme(
    primary = CoralFlameDeep,
    onPrimary = LightSurface,
    primaryContainer = ColorPalette.LightPrimaryContainer,
    onPrimaryContainer = TextPrimaryLight,
    secondary = CyanDeep,
    onSecondary = LightSurface,
    secondaryContainer = ColorPalette.LightSecondaryContainer,
    onSecondaryContainer = TextPrimaryLight,
    tertiary = AmberGold,
    background = LightCanvas,
    onBackground = TextPrimaryLight,
    surface = LightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = TextSecondaryLight,
    outline = LightOutline,
    error = RoseError
)

private object ColorPalette {
    val LightPrimaryContainer = androidx.compose.ui.graphics.Color(0xFFFFE4DC)
    val LightSecondaryContainer = androidx.compose.ui.graphics.Color(0xFFD8F6FC)
}

val StudioShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun AutoClipTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme || isSystemInDarkTheme()) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = StudioShapes,
        content = content
    )
}
