package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AspectRatioPreset
import com.example.data.model.AutoRenderPlan
import com.example.data.model.MediaAsset
import com.example.data.model.RenderJobState
import com.example.data.model.SavedVideoItem
import com.example.data.repository.MediaRepository
import com.example.video_processing.ExportCoordinator
import com.example.video_processing.PromptDirector
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class StudioUiState(
    val selectedAssets: List<MediaAsset> = emptyList(),
    val isInspectingMedia: Boolean = false,
    val promptText: String = "",
    val selectedAspectOverride: AspectRatioPreset = AspectRatioPreset.AUTO,
    val audioUriString: String? = null,
    val audioDisplayName: String? = null,
    val currentPlan: AutoRenderPlan? = null,
    val renderState: RenderJobState = RenderJobState.Idle,
    val activePreviewVideoUri: String? = null
)

class StudioViewModel(application: Application) : AndroidViewModel(application) {

    private val mediaRepository = MediaRepository(application)
    private val exportCoordinator = ExportCoordinator(application)

    private val _uiState = MutableStateFlow(StudioUiState())
    val uiState: StateFlow<StudioUiState> = _uiState.asStateFlow()

    val savedVideos: StateFlow<List<SavedVideoItem>> = mediaRepository.savedVideos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    private var exportObserverJob: Job? = null

    fun onMediaPicked(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            _uiState.update { it.copy(isInspectingMedia = true) }
            val inspected = mediaRepository.inspectPickedUris(uris)
            _uiState.update { state ->
                val existingUris = state.selectedAssets.map { it.uriString }.toSet()
                val merged = state.selectedAssets + inspected.filterNot { it.uriString in existingUris }
                recomputePlan(state.copy(selectedAssets = merged, isInspectingMedia = false))
            }
        }
    }

    fun removeAsset(assetId: String) {
        _uiState.update { state ->
            val updated = state.selectedAssets.filterNot { it.id == assetId }
            recomputePlan(state.copy(selectedAssets = updated))
        }
    }

    fun clearAllAssets() {
        _uiState.update { state ->
            recomputePlan(
                state.copy(
                    selectedAssets = emptyList(),
                    audioUriString = null,
                    audioDisplayName = null
                )
            )
        }
    }

    fun onPromptChanged(newPrompt: String) {
        _uiState.update { state ->
            recomputePlan(state.copy(promptText = newPrompt))
        }
    }

    fun onAspectPresetSelected(preset: AspectRatioPreset) {
        _uiState.update { state ->
            recomputePlan(state.copy(selectedAspectOverride = preset))
        }
    }

    fun onBackgroundAudioPicked(uri: Uri?) {
        if (uri == null) return
        val name = mediaRepository.resolveAudioDisplayName(uri)
        _uiState.update { state ->
            recomputePlan(
                state.copy(
                    audioUriString = uri.toString(),
                    audioDisplayName = name
                )
            )
        }
    }

    fun clearBackgroundAudio() {
        _uiState.update { state ->
            recomputePlan(state.copy(audioUriString = null, audioDisplayName = null))
        }
    }

    fun startAutoCreation() {
        val state = _uiState.value
        if (state.selectedAssets.isEmpty()) return

        exportObserverJob?.cancel()
        exportObserverJob = viewModelScope.launch {
            exportCoordinator.startAutoExport(
                prompt = state.promptText,
                aspectOverride = state.selectedAspectOverride,
                assets = state.selectedAssets,
                audioUriString = state.audioUriString,
                audioDisplayName = state.audioDisplayName
            ).collect { jobState ->
                _uiState.update { it.copy(renderState = jobState) }
                if (jobState is RenderJobState.Completed) {
                    mediaRepository.refreshHistory()
                }
            }
        }
    }

    fun cancelActiveExport() {
        val running = _uiState.value.renderState as? RenderJobState.Running ?: return
        exportCoordinator.cancelExport(running.workId)
        exportObserverJob?.cancel()
        _uiState.update { it.copy(renderState = RenderJobState.Idle) }
    }

    fun resetRenderState() {
        _uiState.update { it.copy(renderState = RenderJobState.Idle) }
    }

    fun openVideoPreview(uriString: String?) {
        _uiState.update { it.copy(activePreviewVideoUri = uriString) }
    }

    fun deleteSavedHistoryItem(id: String) {
        viewModelScope.launch {
            mediaRepository.removeHistoryItem(id)
        }
    }

    private fun recomputePlan(state: StudioUiState): StudioUiState {
        val plan = if (state.selectedAssets.isNotEmpty()) {
            PromptDirector.buildPlan(
                prompt = state.promptText,
                aspectOverride = state.selectedAspectOverride,
                assets = state.selectedAssets,
                audioUriString = state.audioUriString,
                audioDisplayName = state.audioDisplayName
            )
        } else {
            null
        }
        return state.copy(currentPlan = plan)
    }
}
