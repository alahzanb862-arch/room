package com.example.video_processing

import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume

class FFmpegVideoProcessor {

    suspend fun renderVideo(
        arguments: Array<String>,
        expectedDurationMs: Long,
        outputFile: File,
        onProgress: (Int) -> Unit
    ): Result<File> = suspendCancellableCoroutine { continuation ->
        var sessionRef: FFmpegSession? = null
        val safeDuration = expectedDurationMs.coerceAtLeast(1_000L)

        sessionRef = FFmpegKit.executeWithArgumentsAsync(
            arguments,
            { session ->
                if (!continuation.isActive) return@executeWithArgumentsAsync
                val returnCode = session.returnCode
                if (ReturnCode.isSuccess(returnCode) && outputFile.exists() && outputFile.length() > 0L) {
                    onProgress(100)
                    continuation.resume(Result.success(outputFile))
                } else if (ReturnCode.isCancel(returnCode)) {
                    continuation.resume(Result.failure(IllegalStateException("تم إلغاء معالجة الفيديو")))
                } else {
                    val logs = session.allLogsAsString.takeLast(600)
                    continuation.resume(
                        Result.failure(
                            IllegalStateException(
                                "فشل الدمج عبر FFmpeg (code=${returnCode?.value}): $logs"
                            )
                        )
                    )
                }
            },
            { /* log callback unused; full logs captured on failure */ },
            { statistics ->
                val timeMs = statistics.time
                if (timeMs > 0) {
                    val pct = ((timeMs.toDouble() / safeDuration.toDouble()) * 100.0)
                        .toInt()
                        .coerceIn(1, 98)
                    onProgress(pct)
                }
            }
        )

        continuation.invokeOnCancellation {
            sessionRef?.let { session ->
                FFmpegKit.cancel(session.sessionId)
            }
        }
    }
}
