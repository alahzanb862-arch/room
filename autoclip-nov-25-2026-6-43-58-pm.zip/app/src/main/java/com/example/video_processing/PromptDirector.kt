package com.example.video_processing

import com.example.data.model.AspectRatioPreset
import com.example.data.model.AutoRenderPlan
import com.example.data.model.MediaAsset
import com.example.data.model.MediaType
import com.example.data.model.OrderingStrategy
import com.example.data.model.VisualStylePreset
import java.util.Locale

object PromptDirector {

    fun buildPlan(
        prompt: String,
        aspectOverride: AspectRatioPreset,
        assets: List<MediaAsset>,
        audioUriString: String? = null,
        audioDisplayName: String? = null
    ): AutoRenderPlan {
        val normalized = prompt.trim().lowercase(Locale.ROOT)

        val resolvedAspect = resolveAspectRatio(normalized, aspectOverride, assets)
        val stylePreset = resolveVisualStyle(normalized)
        val orderingStrategy = resolveOrderingStrategy(normalized, assets)
        val (photoDurationMs, maxVideoClipMs) = resolvePacing(normalized)

        val orderedAssets = reorderAssets(assets, orderingStrategy)
        val (openingTitle, highlightTag, closingCaption) = extractOverlays(prompt, stylePreset, resolvedAspect)

        return AutoRenderPlan(
            resolvedAspectRatio = resolvedAspect,
            stylePreset = stylePreset,
            orderingStrategy = orderingStrategy,
            photoDurationMs = photoDurationMs,
            maxVideoClipMs = maxVideoClipMs,
            openingTitle = openingTitle,
            highlightTag = highlightTag,
            closingCaption = closingCaption,
            orderedAssets = orderedAssets,
            audioUriString = audioUriString,
            audioDisplayName = audioDisplayName
        )
    }

    private fun resolveAspectRatio(
        normalizedPrompt: String,
        override: AspectRatioPreset,
        assets: List<MediaAsset>
    ): AspectRatioPreset {
        if (override != AspectRatioPreset.AUTO) return override

        val landscapeKeywords = listOf(
            "16:9", "16/9", "landscape", "youtube", "widescreen", "cinema",
            "أفقي", "عرضي", "يوتيوب", "شاشة عريضة", "سينمائي عريض"
        )
        val portraitKeywords = listOf(
            "9:16", "9/16", "portrait", "vertical", "reels", "tiktok", "shorts", "story", "stories",
            "طولي", "عمودي", "ريلز", "تيك توك", "شورتس", "ستوري"
        )

        if (landscapeKeywords.any { normalizedPrompt.contains(it) }) {
            return AspectRatioPreset.LANDSCAPE_16_9
        }
        if (portraitKeywords.any { normalizedPrompt.contains(it) }) {
            return AspectRatioPreset.PORTRAIT_9_16
        }

        if (assets.isNotEmpty()) {
            val landscapeCount = assets.count { it.width > it.height && it.width > 0 }
            val portraitCount = assets.count { it.height >= it.width && it.height > 0 }
            if (landscapeCount > portraitCount) {
                return AspectRatioPreset.LANDSCAPE_16_9
            }
        }
        return AspectRatioPreset.PORTRAIT_9_16
    }

    private fun resolveVisualStyle(normalizedPrompt: String): VisualStylePreset {
        return when {
            containsAny(normalizedPrompt, "أبيض وأسود", "اسود وابيض", "كلاسيك", "noir", "b&w", "monochrome", "black and white") ->
                VisualStylePreset.NOIR_BW
            containsAny(normalizedPrompt, "قديم", "ذكريات", "تراثي", "vintage", "retro", "sepia", "nostalgia") ->
                VisualStylePreset.VINTAGE_SEPIA
            containsAny(normalizedPrompt, "بحر", "بارد", "تقني", "مستقبل", "تكنولوجيا", "ليل", "neon", "tech", "cool", "ocean", "blue", "teal") ->
                VisualStylePreset.TEAL_COOL
            containsAny(normalizedPrompt, "حيوي", "ألوان", "مبهج", "حفلة", "عيد", "رياضة", "أطفال", "vivid", "bright", "colorful", "party", "pop", "sport") ->
                VisualStylePreset.VIVID_POP
            containsAny(normalizedPrompt, "سينما", "سينمائي", "دافئ", "غروب", "فخم", "سفر", "رمضان", "قهوة", "cinematic", "warm", "sunset", "luxury", "travel", "gold") ->
                VisualStylePreset.CINEMATIC_WARM
            else -> VisualStylePreset.NATURAL
        }
    }

    private fun resolveOrderingStrategy(
        normalizedPrompt: String,
        assets: List<MediaAsset>
    ): OrderingStrategy {
        val hasPhotos = assets.any { it.mediaType == MediaType.PHOTO }
        val hasVideos = assets.any { it.mediaType == MediaType.VIDEO }

        return when {
            containsAny(normalizedPrompt, "رحلة", "سفر", "يوميات", "قصة", "ذكريات", "تسلسل", "timeline", "story", "trip", "memories", "vlog") ->
                OrderingStrategy.CHRONOLOGICAL
            hasPhotos && hasVideos && containsAny(normalizedPrompt, "تشويق", "تصاعد", "مقدمة", "عرض", "showcase", "recap", "buildup") ->
                OrderingStrategy.PHOTOS_TO_VIDEO_CLIMAX
            hasPhotos && hasVideos ->
                OrderingStrategy.HOOK_AND_FLOW
            else -> OrderingStrategy.CHRONOLOGICAL
        }
    }

    private fun resolvePacing(normalizedPrompt: String): Pair<Long, Long> {
        return when {
            containsAny(normalizedPrompt, "سريع", "حماس", "رييلز", "ريلز", "تيك توك", "إعلان", "fast", "dynamic", "energetic", "reel", "tiktok", "promo", "action") ->
                1_900L to 4_500L
            containsAny(normalizedPrompt, "هادئ", "بطيء", "رومانسي", "تأمل", "ذكريات", "calm", "slow", "relaxing", "chill", "cinematic") ->
                3_800L to 8_000L
            else ->
                2_800L to 6_000L
        }
    }

    private fun reorderAssets(
        assets: List<MediaAsset>,
        strategy: OrderingStrategy
    ): List<MediaAsset> {
        if (assets.size <= 1) return assets

        return when (strategy) {
            OrderingStrategy.CHRONOLOGICAL -> {
                assets.sortedBy { it.dateAddedSec }
            }
            OrderingStrategy.PHOTOS_TO_VIDEO_CLIMAX -> {
                val photos = assets.filter { it.mediaType == MediaType.PHOTO }.sortedBy { it.dateAddedSec }
                val videos = assets.filter { it.mediaType == MediaType.VIDEO }.sortedBy { it.dateAddedSec }
                photos + videos
            }
            OrderingStrategy.HOOK_AND_FLOW -> {
                val videos = assets.filter { it.mediaType == MediaType.VIDEO }.toMutableList()
                val photos = assets.filter { it.mediaType == MediaType.PHOTO }.toMutableList()
                if (videos.isEmpty()) return photos
                if (photos.isEmpty()) return videos

                val result = mutableListOf<MediaAsset>()
                result.add(videos.removeAt(0))
                while (photos.isNotEmpty() || videos.isNotEmpty()) {
                    if (photos.isNotEmpty()) result.add(photos.removeAt(0))
                    if (photos.isNotEmpty() && photos.size > videos.size) result.add(photos.removeAt(0))
                    if (videos.isNotEmpty()) result.add(videos.removeAt(0))
                }
                result
            }
        }
    }

    private fun extractOverlays(
        rawPrompt: String,
        stylePreset: VisualStylePreset,
        aspectRatio: AspectRatioPreset
    ): Triple<String, String, String> {
        val cleaned = rawPrompt
            .replace(Regex("9\\s*[:/]\\s*16|16\\s*[:/]\\s*9", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\s+"), " ")
            .trim()

        val title = if (cleaned.isNotBlank()) {
            val words = cleaned.split(" ").filter { it.isNotBlank() }
            val snippet = words.take(6).joinToString(" ")
            if (words.size > 6) "$snippet..." else snippet
        } else {
            "لحظات مميزة"
        }

        val highlightTag = "${aspectRatio.ratioLabel} • ${stylePreset.badgeEn}"
        val closingCaption = "AutoClip Studio"
        return Triple(title, highlightTag, closingCaption)
    }

    private fun containsAny(text: String, vararg keywords: String): Boolean {
        return keywords.any { text.contains(it) }
    }
}
