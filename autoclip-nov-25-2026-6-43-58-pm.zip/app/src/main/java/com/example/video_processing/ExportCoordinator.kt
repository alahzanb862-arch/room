package com.example.video_processing

import android.content.Context
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.example.data.model.AspectRatioPreset
import com.example.data.model.MediaAsset
import com.example.data.model.RenderJobState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

class ExportCoordinator(context: Context) {

    private val workManager = WorkManager.getInstance(context.applicationContext)

    fun startAutoExport(
        prompt: String,
        aspectOverride: AspectRatioPreset,
        assets: List<MediaAsset>,
        audioUriString: String?,
        audioDisplayName: String?
    ): Flow<RenderJobState> {
        val inputData = workDataOf(
            AutoVideoExportWorker.KEY_PROMPT to prompt,
            AutoVideoExportWorker.KEY_ASPECT_ID to aspectOverride.id,
            AutoVideoExportWorker.KEY_AUDIO_URI to audioUriString,
            AutoVideoExportWorker.KEY_AUDIO_NAME to audioDisplayName,
            AutoVideoExportWorker.KEY_ASSETS_JSON to AutoVideoExportWorker.serializeAssets(assets)
        )

        val request = OneTimeWorkRequestBuilder<AutoVideoExportWorker>()
            .setInputData(inputData)
            .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
            .addTag(WORK_TAG)
            .build()

        workManager.enqueueUniqueWork(UNIQUE_WORK_NAME, ExistingWorkPolicy.REPLACE, request)
        return observeWork(request.id)
    }

    fun cancelExport(workId: String) {
        runCatching {
            workManager.cancelWorkById(UUID.fromString(workId))
        }
    }

    private fun observeWork(id: UUID): Flow<RenderJobState> {
        return workManager.getWorkInfoByIdFlow(id).map { info ->
            if (info == null) return@map RenderJobState.Idle
            when (info.state) {
                WorkInfo.State.ENQUEUED,
                WorkInfo.State.BLOCKED -> RenderJobState.Running(
                    workId = id.toString(),
                    progressPercent = 2,
                    stageTitle = "تحضير مهمة المعالجة في الخلفية",
                    stageDetail = "جاري بدء محرك FFmpeg..."
                )
                WorkInfo.State.RUNNING -> {
                    val pct = info.progress.getInt(AutoVideoExportWorker.KEY_PROGRESS, 5)
                    val title = info.progress.getString(AutoVideoExportWorker.KEY_STAGE_TITLE)
                        ?: "جاري إنشاء الفيديو تلقائياً"
                    val detail = info.progress.getString(AutoVideoExportWorker.KEY_STAGE_DETAIL)
                        ?: "يتم التوحيد والدمج بدون تدخل يدوي"
                    RenderJobState.Running(
                        workId = id.toString(),
                        progressPercent = pct,
                        stageTitle = title,
                        stageDetail = detail
                    )
                }
                WorkInfo.State.SUCCEEDED -> {
                    val outputUri = info.outputData.getString(AutoVideoExportWorker.KEY_OUTPUT_URI).orEmpty()
                    val outputName = info.outputData.getString(AutoVideoExportWorker.KEY_OUTPUT_NAME) ?: "AutoClip.mp4"
                    val durationMs = info.outputData.getLong(AutoVideoExportWorker.KEY_OUTPUT_DURATION, 0L)
                    val sizeBytes = info.outputData.getLong(AutoVideoExportWorker.KEY_OUTPUT_SIZE, 0L)
                    val aspect = info.outputData.getString(AutoVideoExportWorker.KEY_OUTPUT_ASPECT) ?: "9:16"
                    RenderJobState.Completed(
                        outputUriString = outputUri,
                        fileName = outputName,
                        durationMs = durationMs,
                        fileSizeBytes = sizeBytes,
                        aspectLabel = aspect
                    )
                }
                WorkInfo.State.FAILED -> {
                    val msg = info.outputData.getString(AutoVideoExportWorker.KEY_ERROR)
                        ?: "تعذر إكمال دمج الفيديو"
                    RenderJobState.Failed(msg)
                }
                WorkInfo.State.CANCELLED -> RenderJobState.Idle
            }
        }
    }

    companion object {
        private const val UNIQUE_WORK_NAME = "autoclip_unique_render"
        private const val WORK_TAG = "autoclip_render"
    }
}
