package com.example.video_processing

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.res.ResourcesCompat
import com.example.R
import java.io.File

object OverlayBitmapFactory {

    fun writeTitleBannerPng(
        context: Context,
        outputFile: File,
        titleText: String,
        subtitleBadge: String,
        targetWidth: Int,
        targetHeight: Int
    ): File {
        val bitmap = createTitleBannerBitmap(context, titleText, subtitleBadge, targetWidth, targetHeight)
        outputFile.parentFile?.mkdirs()
        outputFile.outputStream().use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        bitmap.recycle()
        return outputFile
    }

    fun writeWatermarkPng(
        context: Context,
        outputFile: File,
        caption: String
    ): File {
        val bitmap = createWatermarkBitmap(context, caption)
        outputFile.parentFile?.mkdirs()
        outputFile.outputStream().use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        bitmap.recycle()
        return outputFile
    }

    private fun createTitleBannerBitmap(
        context: Context,
        titleText: String,
        subtitleBadge: String,
        targetWidth: Int,
        targetHeight: Int
    ): Bitmap {
        val isPortrait = targetHeight > targetWidth
        val bannerWidth = (targetWidth * if (isPortrait) 0.86f else 0.58f).toInt().coerceAtLeast(480)
        val horizontalPad = 36f
        val topPad = 24f
        val bottomPad = 24f

        val cairoTypeface = ResourcesCompat.getFont(context, R.font.cairo) ?: Typeface.DEFAULT_BOLD
        val spaceTypeface = ResourcesCompat.getFont(context, R.font.space_grotesk) ?: Typeface.DEFAULT_BOLD

        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = if (isPortrait) 44f else 40f
            typeface = Typeface.create(cairoTypeface, Typeface.BOLD)
            setShadowLayer(8f, 0f, 3f, Color.argb(180, 0, 0, 0))
        }

        val badgePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#22D3EE")
            textSize = if (isPortrait) 24f else 22f
            typeface = Typeface.create(spaceTypeface, Typeface.BOLD)
        }

        val textMaxWidth = (bannerWidth - horizontalPad * 2).toInt().coerceAtLeast(200)
        val titleLayout = StaticLayout.Builder
            .obtain(titleText, 0, titleText.length, titlePaint, textMaxWidth)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setLineSpacing(6f, 1.0f)
            .setMaxLines(2)
            .build()

        val badgeHeight = badgePaint.fontMetrics.let { it.descent - it.ascent }
        val totalHeight = (topPad + badgeHeight + 12f + titleLayout.height + bottomPad).toInt()
            .coerceAtLeast(120)

        val bitmap = Bitmap.createBitmap(bannerWidth, totalHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val bgRect = RectF(0f, 0f, bannerWidth.toFloat(), totalHeight.toFloat())
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f, 0f, bannerWidth.toFloat(), totalHeight.toFloat(),
                intArrayOf(
                    Color.argb(210, 14, 19, 30),
                    Color.argb(190, 26, 34, 52)
                ),
                null,
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRoundRect(bgRect, 28f, 28f, bgPaint)

        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2.5f
            color = Color.argb(130, 255, 99, 66)
        }
        canvas.drawRoundRect(
            RectF(1.5f, 1.5f, bannerWidth - 1.5f, totalHeight - 1.5f),
            28f,
            28f,
            borderPaint
        )

        val badgeTextWidth = badgePaint.measureText(subtitleBadge)
        val badgeX = (bannerWidth - badgeTextWidth) / 2f
        val badgeY = topPad - badgePaint.fontMetrics.ascent
        canvas.drawText(subtitleBadge, badgeX, badgeY, badgePaint)

        canvas.save()
        canvas.translate(horizontalPad, topPad + badgeHeight + 12f)
        titleLayout.draw(canvas)
        canvas.restore()

        return bitmap
    }

    private fun createWatermarkBitmap(context: Context, caption: String): Bitmap {
        val spaceTypeface = ResourcesCompat.getFont(context, R.font.space_grotesk) ?: Typeface.DEFAULT_BOLD
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(235, 243, 246, 252)
            textSize = 24f
            typeface = Typeface.create(spaceTypeface, Typeface.BOLD)
        }

        val textWidth = paint.measureText(caption)
        val width = (textWidth + 48f).toInt().coerceAtLeast(180)
        val height = 54

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val pillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(165, 11, 14, 20)
        }
        canvas.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), 27f, 27f, pillPaint)

        val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FF6342")
        }
        canvas.drawCircle(20f, height / 2f, 5.5f, dotPaint)

        val baseline = (height - (paint.fontMetrics.descent + paint.fontMetrics.ascent)) / 2f
        canvas.drawText(caption, 34f, baseline, paint)

        return bitmap
    }
}
