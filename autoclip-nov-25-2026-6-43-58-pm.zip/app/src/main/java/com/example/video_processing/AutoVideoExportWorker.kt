package com.example.video_processing

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.example.R
import com.example.data.model.AspectRatioPreset
import com.example.data.model.MediaAsset
import com.example.data.model.MediaType
import com.example.data.repository.MediaRepository
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AutoVideoExportWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    private val mediaRepository = MediaRepository(appContext)
    private val videoProcessor = FFmpegVideoProcessor()

    override suspend fun doWork(): Result {
        val prompt = inputData.getString(KEY_PROMPT).orEmpty()
        val aspectId = inputData.getString(KEY_ASPECT_ID) ?: AspectRatioPreset.AUTO.id
        val audioUriString = inputData.getString(KEY_AUDIO_URI)
        val audioDisplayName = inputData.getString(KEY_AUDIO_NAME)
        val assetsJson = inputData.getString(KEY_ASSETS_JSON).orEmpty()

        val assets = parseAssetsJson(assetsJson)
        if (assets.isEmpty()) {
            return Result.failure(workDataOf(KEY_ERROR to "لم يتم اختيار أي صور أو فيديوهات"))
        }

        val plan = PromptDirector.buildPlan(
            prompt = prompt,
            aspectOverride = AspectRatioPreset.fromId(aspectId),
            assets = assets,
            audioUriString = audioUriString,
            audioDisplayName = audioDisplayName
        )

        val workDir = File(applicationContext.cacheDir, "autoclip_job_${id}").apply { mkdirs() }

        return try {
            updateProgress(
                percent = 5,
                stageTitle = "تحليل الفكرة وتجهيز الملفات",
                stageDetail = "ترتيب ${plan.orderedAssets.size} ملفات وتجهيز مقاس ${plan.resolvedAspectRatio.ratioLabel}"
            )

            // 1. Stage all picked URIs into local cache files for reliable FFmpeg processing
            val stagedAssets = mutableListOf<StagedAsset>()
            plan.orderedAssets.forEachIndexed { index, asset ->
                if (isStopped) return Result.failure(workDataOf(KEY_ERROR to "تم إلغاء المعالجة"))
                val ext = if (asset.mediaType == MediaType.PHOTO) "jpg" else "mp4"
                val stagedFile = File(workDir, "input_${index}.$ext")
                val copied = mediaRepository.stageMediaToFile(asset.uriString, stagedFile)
                if (!copied) {
                    return Result.failure(
                        workDataOf(KEY_ERROR to "تعذر قراءة الملف: ${asset.displayName}")
                    )
                }
                stagedAssets.add(StagedAsset(asset, stagedFile))
                val stagingPct = 5 + (((index + 1) * 10) / plan.orderedAssets.size)
                updateProgress(
                    percent = stagingPct,
                    stageTitle = "تجهيز الوسائط (${index + 1}/${plan.orderedAssets.size})",
                    stageDetail = asset.displayName
                )
            }

            // Stage optional background audio
            val stagedAudio = if (!plan.audioUriString.isNullOrBlank()) {
                val audioFile = File(workDir, "bg_audio.m4a")
                if (mediaRepository.stageMediaToFile(plan.audioUriString, audioFile)) audioFile else null
            } else {
                null
            }

            // 2. Render RTL-safe overlay PNGs
            updateProgress(
                percent = 18,
                stageTitle = "إنشاء النصوص والملصقات التلقائية",
                stageDetail = plan.openingTitle
            )
            val titlePng = OverlayBitmapFactory.writeTitleBannerPng(
                context = applicationContext,
                outputFile = File(workDir, "overlay_title.png"),
                titleText = plan.openingTitle,
                subtitleBadge = plan.highlightTag,
                targetWidth = plan.resolvedAspectRatio.targetWidth,
                targetHeight = plan.resolvedAspectRatio.targetHeight
            )
            val watermarkPng = OverlayBitmapFactory.writeWatermarkPng(
                context = applicationContext,
                outputFile = File(workDir, "overlay_watermark.png"),
                caption = plan.closingCaption
            )

            // 3. Build FFmpeg arguments and render in background
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val outputFileName = "AutoClip_${timestamp}.mp4"
            val outputTempFile = File(workDir, outputFileName)

            val ffmpegArgs = FfmpegCommandBuilder.buildArguments(
                plan = plan,
                stagedAssets = stagedAssets,
                titleOverlayPng = titlePng,
                watermarkOverlayPng = watermarkPng,
                backgroundAudioFile = stagedAudio,
                outputFile = outputTempFile
            )

            updateProgress(
                percent = 22,
                stageTitle = "توحيد الأبعاد ودمج الفيديو",
                stageDetail = "${plan.resolvedAspectRatio.targetWidth}×${plan.resolvedAspectRatio.targetHeight} • ${plan.stylePreset.labelAr}"
            )

            val renderResult = videoProcessor.renderVideo(
                arguments = ffmpegArgs,
                expectedDurationMs = plan.estimatedDurationMs,
                outputFile = outputTempFile
            ) { ffmpegPct ->
                val mappedPct = 22 + ((ffmpegPct * 70) / 100)
                setProgressAsync(
                    workDataOf(
                        KEY_PROGRESS to mappedPct,
                        KEY_STAGE_TITLE to "جاري الدمج والإخراج عبر FFmpeg",
                        KEY_STAGE_DETAIL to "تطبيق الفلتر (${plan.stylePreset.labelAr}) وتوحيد الإطارات"
                    )
                )
            }

            if (renderResult.isFailure) {
                val err = renderResult.exceptionOrNull()?.message ?: "حدث خطأ غير متوقع أثناء المعالجة"
                return Result.failure(workDataOf(KEY_ERROR to err))
            }

            // 4. Save automatically to device gallery via MediaStore
            updateProgress(
                percent = 95,
                stageTitle = "حفظ الفيديو على الهاتف",
                stageDetail = "Movies/AutoClip/$outputFileName"
            )

            val savedItem = mediaRepository.saveRenderedVideo(
                renderedFile = outputTempFile,
                fileName = outputFileName,
                durationMs = plan.estimatedDurationMs,
                aspectLabel = plan.resolvedAspectRatio.ratioLabel,
                promptSummary = plan.openingTitle
            )

            Result.success(
                workDataOf(
                    KEY_OUTPUT_URI to savedItem.uriString,
                    KEY_OUTPUT_NAME to savedItem.displayName,
                    KEY_OUTPUT_DURATION to savedItem.durationMs,
                    KEY_OUTPUT_SIZE to savedItem.sizeBytes,
                    KEY_OUTPUT_ASPECT to savedItem.aspectLabel
                )
            )
        } catch (e: Exception) {
            Result.failure(workDataOf(KEY_ERROR to (e.message ?: "فشلت عملية إنشاء الفيديو")))
        } finally {
            workDir.deleteRecursively()
        }
    }

    private suspend fun updateProgress(
        percent: Int,
        stageTitle: String,
        stageDetail: String
    ) {
        setProgress(
            workDataOf(
                KEY_PROGRESS to percent,
                KEY_STAGE_TITLE to stageTitle,
                KEY_STAGE_DETAIL to stageDetail
            )
        )
        runCatching {
            setForeground(createForegroundInfo(percent, stageTitle))
        }
    }

    private fun createForegroundInfo(percent: Int, stageTitle: String): ForegroundInfo {
        ensureNotificationChannel()
        val title = applicationContext.getString(R.string.notification_title_rendering)
        val cancelText = applicationContext.getString(R.string.notification_action_cancel)
        val cancelIntent = WorkManager.getInstance(applicationContext).createCancelPendingIntent(id)

        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText("$stageTitle ($percent%)")
            .setProgress(100, percent.coerceIn(0, 100), false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, cancelText, cancelIntent)
            .build()

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            ForegroundInfo(NOTIFICATION_ID, notification)
        }
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (manager.getNotificationChannel(CHANNEL_ID) == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    applicationContext.getString(R.string.notification_channel_name),
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = applicationContext.getString(R.string.notification_channel_description)
                }
                manager.createNotificationChannel(channel)
            }
        }
    }

    companion object {
        private const val CHANNEL_ID = "autoclip_render_channel"
        private const val NOTIFICATION_ID = 4102

        const val KEY_PROMPT = "key_prompt"
        const val KEY_ASPECT_ID = "key_aspect_id"
        const val KEY_AUDIO_URI = "key_audio_uri"
        const val KEY_AUDIO_NAME = "key_audio_name"
        const val KEY_ASSETS_JSON = "key_assets_json"

        const val KEY_PROGRESS = "key_progress"
        const val KEY_STAGE_TITLE = "key_stage_title"
        const val KEY_STAGE_DETAIL = "key_stage_detail"

        const val KEY_OUTPUT_URI = "key_output_uri"
        const val KEY_OUTPUT_NAME = "key_output_name"
        const val KEY_OUTPUT_DURATION = "key_output_duration"
        const val KEY_OUTPUT_SIZE = "key_output_size"
        const val KEY_OUTPUT_ASPECT = "key_output_aspect"
        const val KEY_ERROR = "key_error"

        fun serializeAssets(assets: List<MediaAsset>): String {
            val array = JSONArray()
            assets.forEach { asset ->
                array.put(
                    JSONObject().apply {
                        put("id", asset.id)
                        put("uriString", asset.uriString)
                        put("mediaType", asset.mediaType.name)
                        put("displayName", asset.displayName)
                        put("durationMs", asset.durationMs)
                        put("width", asset.width)
                        put("height", asset.height)
                        put("dateAddedSec", asset.dateAddedSec)
                        put("hasAudioTrack", asset.hasAudioTrack)
                    }
                )
            }
            return array.toString()
        }

        fun parseAssetsJson(raw: String): List<MediaAsset> {
            if (raw.isBlank()) return emptyList()
            return runCatching {
                val array = JSONArray(raw)
                buildList {
                    for (i in 0 until array.length()) {
                        val obj = array.getJSONObject(i)
                        add(
                            MediaAsset(
                                id = obj.optString("id"),
                                uriString = obj.optString("uriString"),
                                mediaType = MediaType.valueOf(obj.optString("mediaType", MediaType.PHOTO.name)),
                                displayName = obj.optString("displayName"),
                                durationMs = obj.optLong("durationMs"),
                                width = obj.optInt("width", 1080),
                                height = obj.optInt("height", 1920),
                                dateAddedSec = obj.optLong("dateAddedSec"),
                                hasAudioTrack = obj.optBoolean("hasAudioTrack", false)
                            )
                        )
                    }
                }
            }.getOrDefault(emptyList())
        }
    }
}
