package com.example.video_processing

import com.example.data.model.AutoRenderPlan
import com.example.data.model.MediaAsset
import com.example.data.model.MediaType
import java.io.File
import java.util.Locale

data class StagedAsset(
    val asset: MediaAsset,
    val file: File
)

object FfmpegCommandBuilder {

    fun buildArguments(
        plan: AutoRenderPlan,
        stagedAssets: List<StagedAsset>,
        titleOverlayPng: File,
        watermarkOverlayPng: File,
        backgroundAudioFile: File?,
        outputFile: File
    ): Array<String> {
        val args = mutableListOf<String>()
        args.add("-y")

        val targetW = plan.resolvedAspectRatio.targetWidth
        val targetH = plan.resolvedAspectRatio.targetHeight
        val photoSec = String.format(Locale.US, "%.2f", plan.photoDurationMs / 1000.0)
        val maxVideoSec = String.format(Locale.US, "%.2f", plan.maxVideoClipMs / 1000.0)

        // 1. Add media inputs (photos looped to photoDurationMs, videos trimmed to maxVideoClipMs)
        stagedAssets.forEach { staged ->
            if (staged.asset.mediaType == MediaType.PHOTO) {
                args.add("-loop")
                args.add("1")
                args.add("-t")
                args.add(photoSec)
                args.add("-i")
                args.add(staged.file.absolutePath)
            } else {
                val clipDurationMs = staged.asset.durationMs
                if (clipDurationMs > plan.maxVideoClipMs && plan.maxVideoClipMs > 0L) {
                    args.add("-t")
                    args.add(maxVideoSec)
                }
                args.add("-i")
                args.add(staged.file.absolutePath)
            }
        }

        // 2. Add overlay PNG inputs
        val titleOverlayIdx = stagedAssets.size
        args.add("-i")
        args.add(titleOverlayPng.absolutePath)

        val watermarkOverlayIdx = stagedAssets.size + 1
        args.add("-i")
        args.add(watermarkOverlayPng.absolutePath)

        // 3. Add optional background audio input (looped indefinitely, truncated with -shortest)
        val bgAudioIdx = if (backgroundAudioFile != null) stagedAssets.size + 2 else -1
        if (backgroundAudioFile != null) {
            args.add("-stream_loop")
            args.add("-1")
            args.add("-i")
            args.add(backgroundAudioFile.absolutePath)
        }

        // 4. Build filter_complex graph
        val hasVideoAudio = stagedAssets.any { it.asset.mediaType == MediaType.VIDEO && it.asset.hasAudioTrack }
        val includeClipAudio = backgroundAudioFile == null && hasVideoAudio
        val filterChains = mutableListOf<String>()

        // Normalize every asset to exact target dimensions, 30 fps, yuv420p, SAR=1
        stagedAssets.forEachIndexed { index, staged ->
            filterChains.add(
                "[$index:v]scale=$targetW:$targetH:force_original_aspect_ratio=increase," +
                    "crop=$targetW:$targetH,setsar=1,fps=30,format=yuv420p[v$index]"
            )

            if (includeClipAudio) {
                if (staged.asset.mediaType == MediaType.VIDEO && staged.asset.hasAudioTrack) {
                    filterChains.add(
                        "[$index:a]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo[a$index]"
                    )
                } else {
                    val durMs = if (staged.asset.mediaType == MediaType.PHOTO) {
                        plan.photoDurationMs
                    } else {
                        minOf(staged.asset.durationMs.coerceAtLeast(1000L), plan.maxVideoClipMs)
                    }
                    val durSec = String.format(Locale.US, "%.2f", durMs / 1000.0)
                    filterChains.add(
                        "anullsrc=channel_layout=stereo:sample_rate=44100,atrim=0:$durSec[a$index]"
                    )
                }
            }
        }

        // Concatenate all normalized clips
        val concatInputs = buildString {
            stagedAssets.indices.forEach { i ->
                append("[v$i]")
                if (includeClipAudio) append("[a$i]")
            }
        }
        val concatOutput = if (includeClipAudio) "[vcat][acat]" else "[vcat]"
        val concatAudioFlag = if (includeClipAudio) 1 else 0
        filterChains.add(
            "${concatInputs}concat=n=${stagedAssets.size}:v=1:a=$concatAudioFlag$concatOutput"
        )

        // Apply visual color grade from PromptDirector
        val colorFilter = plan.stylePreset.ffmpegColorFilter
        filterChains.add("[vcat]$colorFilter[vstyled]")

        // Overlay RTL title banner during first 3.6 seconds, then persistent studio watermark pill
        val totalSec = plan.estimatedDurationMs / 1000.0
        val titleEnd = minOf(3.6, totalSec).let { String.format(Locale.US, "%.2f", it) }
        filterChains.add(
            "[vstyled][$titleOverlayIdx:v]overlay=(W-w)/2:88:enable='between(t,0.15,$titleEnd)'[vwithtitle]"
        )
        filterChains.add(
            "[vwithtitle][$watermarkOverlayIdx:v]overlay=W-w-36:H-h-44[vfinal]"
        )

        args.add("-filter_complex")
        args.add(filterChains.joinToString(";"))

        // 5. Output stream mappings & encoding params
        args.add("-map")
        args.add("[vfinal]")

        if (backgroundAudioFile != null && bgAudioIdx >= 0) {
            args.add("-map")
            args.add("$bgAudioIdx:a")
            args.add("-shortest")
            args.add("-c:a")
            args.add("aac")
            args.add("-b:a")
            args.add("128k")
        } else if (includeClipAudio) {
            args.add("-map")
            args.add("[acat]")
            args.add("-c:a")
            args.add("aac")
            args.add("-b:a")
            args.add("128k")
        }

        args.add("-c:v")
        args.add("libx264")
        args.add("-preset")
        args.add("veryfast")
        args.add("-crf")
        args.add("22")
        args.add("-pix_fmt")
        args.add("yuv420p")
        args.add("-movflags")
        args.add("+faststart")
        args.add(outputFile.absolutePath)

        return args.toTypedArray()
    }
}
