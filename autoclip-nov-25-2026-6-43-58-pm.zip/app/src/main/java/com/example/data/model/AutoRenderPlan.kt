package com.example.data.model

data class AutoRenderPlan(
    val resolvedAspectRatio: AspectRatioPreset,
    val stylePreset: VisualStylePreset,
    val orderingStrategy: OrderingStrategy,
    val photoDurationMs: Long,
    val maxVideoClipMs: Long,
    val openingTitle: String,
    val highlightTag: String,
    val closingCaption: String,
    val orderedAssets: List<MediaAsset>,
    val audioUriString: String? = null,
    val audioDisplayName: String? = null
) {
    val estimatedDurationMs: Long
        get() = orderedAssets.sumOf { asset ->
            when (asset.mediaType) {
                MediaType.PHOTO -> photoDurationMs
                MediaType.VIDEO -> {
                    val raw = if (asset.durationMs > 0L) asset.durationMs else 4_000L
                    minOf(raw, maxVideoClipMs)
                }
            }
        }
}
