package com.example.data.model

sealed interface RenderJobState {
    data object Idle : RenderJobState

    data class Running(
        val workId: String,
        val progressPercent: Int,
        val stageTitle: String,
        val stageDetail: String
    ) : RenderJobState

    data class Completed(
        val outputUriString: String,
        val fileName: String,
        val durationMs: Long,
        val fileSizeBytes: Long,
        val aspectLabel: String
    ) : RenderJobState

    data class Failed(
        val message: String
    ) : RenderJobState
}
