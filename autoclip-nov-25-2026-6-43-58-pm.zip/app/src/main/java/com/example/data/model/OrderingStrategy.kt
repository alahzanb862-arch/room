package com.example.data.model

enum class OrderingStrategy(
    val id: String,
    val labelAr: String,
    val descriptionAr: String
) {
    HOOK_AND_FLOW(
        id = "hook_and_flow",
        labelAr = "افتتاحية فيديو + تناوب ذكي",
        descriptionAr = "يبدأ بأفضل مقطع فيديو لجذب الانتباه ثم يوزع الصور والفيديوهات بإيقاع متوازن"
    ),
    CHRONOLOGICAL(
        id = "chronological",
        labelAr = "تسلسل زمني للرحلة والذكريات",
        descriptionAr = "يرتب اللقطات حسب ترتيب الالتقاط لبناء قصة متسلسلة"
    ),
    PHOTOS_TO_VIDEO_CLIMAX(
        id = "photos_to_climax",
        labelAr = "تمهيد بالصور ثم ذروة الفيديو",
        descriptionAr = "يستعرض الصور بتصاعد هادئ ثم ينتقل لمقاطع الفيديو المتحركة"
    );

    companion object {
        fun fromId(id: String?): OrderingStrategy =
            entries.firstOrNull { it.id == id } ?: HOOK_AND_FLOW
    }
}
