package com.example.data.model

enum class VisualStylePreset(
    val id: String,
    val labelAr: String,
    val badgeEn: String,
    val ffmpegColorFilter: String
) {
    NATURAL(
        id = "natural",
        labelAr = "طبيعي نقي",
        badgeEn = "Natural",
        ffmpegColorFilter = "eq=contrast=1.04:saturation=1.06"
    ),
    CINEMATIC_WARM(
        id = "cinematic_warm",
        labelAr = "سينمائي دافئ",
        badgeEn = "Cinema Warm",
        ffmpegColorFilter = "eq=contrast=1.12:saturation=1.10:brightness=0.01,colorbalance=rs=0.06:gs=0.02:bs=-0.05"
    ),
    TEAL_COOL(
        id = "teal_cool",
        labelAr = "أزرق بارد عصري",
        badgeEn = "Cool Teal",
        ffmpegColorFilter = "eq=contrast=1.10:saturation=1.08,colorbalance=rs=-0.05:gs=0.02:bs=0.07"
    ),
    VIVID_POP(
        id = "vivid_pop",
        labelAr = "حيوي مشرق",
        badgeEn = "Vivid Pop",
        ffmpegColorFilter = "eq=contrast=1.08:saturation=1.28:brightness=0.02"
    ),
    NOIR_BW(
        id = "noir_bw",
        labelAr = "كلاسيكي أبيض وأسود",
        badgeEn = "Noir B&W",
        ffmpegColorFilter = "hue=s=0,eq=contrast=1.20"
    ),
    VINTAGE_SEPIA(
        id = "vintage_sepia",
        labelAr = "ذكريات قديمة",
        badgeEn = "Vintage",
        ffmpegColorFilter = "eq=contrast=1.06:saturation=0.72,colorbalance=rs=0.08:gs=0.03:bs=-0.08"
    );

    companion object {
        fun fromId(id: String?): VisualStylePreset =
            entries.firstOrNull { it.id == id } ?: NATURAL
    }
}
