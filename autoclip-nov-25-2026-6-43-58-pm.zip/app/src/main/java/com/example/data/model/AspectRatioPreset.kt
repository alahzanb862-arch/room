package com.example.data.model

enum class AspectRatioPreset(
    val id: String,
    val labelAr: String,
    val ratioLabel: String,
    val targetWidth: Int,
    val targetHeight: Int
) {
    AUTO(
        id = "auto",
        labelAr = "تلقائي من الفكرة",
        ratioLabel = "Auto",
        targetWidth = 1080,
        targetHeight = 1920
    ),
    PORTRAIT_9_16(
        id = "9:16",
        labelAr = "9:16 طولي (Reels / Shorts)",
        ratioLabel = "9:16",
        targetWidth = 1080,
        targetHeight = 1920
    ),
    LANDSCAPE_16_9(
        id = "16:9",
        labelAr = "16:9 عرضي (YouTube / أفقي)",
        ratioLabel = "16:9",
        targetWidth = 1920,
        targetHeight = 1080
    );

    companion object {
        fun fromId(id: String?): AspectRatioPreset =
            entries.firstOrNull { it.id == id } ?: PORTRAIT_9_16
    }
}
