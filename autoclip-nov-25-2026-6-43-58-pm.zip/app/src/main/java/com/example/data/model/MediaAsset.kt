package com.example.data.model

enum class MediaType {
    PHOTO,
    VIDEO
}

data class MediaAsset(
    val id: String,
    val uriString: String,
    val mediaType: MediaType,
    val displayName: String,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val dateAddedSec: Long,
    val hasAudioTrack: Boolean = false
) {
    val isPortrait: Boolean get() = height > width
}
