package com.example.data.model

data class SavedVideoItem(
    val id: String,
    val uriString: String,
    val displayName: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val createdAtMillis: Long,
    val aspectLabel: String,
    val promptSummary: String
)
