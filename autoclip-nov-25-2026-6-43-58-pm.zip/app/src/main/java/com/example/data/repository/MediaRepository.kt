package com.example.data.repository

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import com.example.data.model.MediaAsset
import com.example.data.model.MediaType
import com.example.data.model.SavedVideoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class MediaRepository(private val context: Context) {

    private val historyFile: File by lazy {
        File(context.filesDir, "autoclip_exports_history.json")
    }

    private val _savedVideos = MutableStateFlow<List<SavedVideoItem>>(emptyList())
    val savedVideos: Flow<List<SavedVideoItem>> = _savedVideos.asStateFlow()

    init {
        _savedVideos.value = readHistoryFromDisk()
    }

    suspend fun inspectPickedUris(uris: List<Uri>): List<MediaAsset> = withContext(Dispatchers.IO) {
        uris.mapNotNull { uri ->
            tryTakePersistablePermission(uri)
            inspectSingleUri(uri)
        }
    }

    fun resolveAudioDisplayName(uri: Uri): String {
        tryTakePersistablePermission(uri)
        return queryDisplayName(uri) ?: "موسيقى خلفية"
    }

    suspend fun stageMediaToFile(uriString: String, targetFile: File): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val uri = Uri.parse(uriString)
            targetFile.parentFile?.mkdirs()
            context.contentResolver.openInputStream(uri)?.use { input ->
                targetFile.outputStream().use { output ->
                    input.copyTo(output, bufferSize = 64 * 1024)
                }
            } ?: return@runCatching false
            targetFile.exists() && targetFile.length() > 0L
        }.getOrDefault(false)
    }

    suspend fun saveRenderedVideo(
        renderedFile: File,
        fileName: String,
        durationMs: Long,
        aspectLabel: String,
        promptSummary: String
    ): SavedVideoItem = withContext(Dispatchers.IO) {
        val sizeBytes = renderedFile.length()
        val finalUriString = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            saveViaMediaStoreQPlus(renderedFile, fileName)
        } else {
            saveViaAppMoviesDir(renderedFile, fileName)
        }

        val item = SavedVideoItem(
            id = UUID.randomUUID().toString(),
            uriString = finalUriString,
            displayName = fileName,
            durationMs = durationMs,
            sizeBytes = sizeBytes,
            createdAtMillis = System.currentTimeMillis(),
            aspectLabel = aspectLabel,
            promptSummary = promptSummary
        )

        val updated = listOf(item) + _savedVideos.value.filterNot { it.id == item.id }
        _savedVideos.value = updated
        writeHistoryToDisk(updated)
        item
    }

    suspend fun removeHistoryItem(id: String) = withContext(Dispatchers.IO) {
        val updated = _savedVideos.value.filterNot { it.id == id }
        _savedVideos.value = updated
        writeHistoryToDisk(updated)
    }

    fun refreshHistory() {
        _savedVideos.value = readHistoryFromDisk()
    }

    private fun saveViaMediaStoreQPlus(sourceFile: File, fileName: String): String {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/AutoClip")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }

        val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val itemUri = resolver.insert(collection, values)
            ?: return saveViaAppMoviesDir(sourceFile, fileName)

        return try {
            resolver.openOutputStream(itemUri)?.use { out ->
                sourceFile.inputStream().use { input ->
                    input.copyTo(out, bufferSize = 64 * 1024)
                }
            }
            val publishValues = ContentValues().apply {
                put(MediaStore.Video.Media.IS_PENDING, 0)
            }
            resolver.update(itemUri, publishValues, null, null)
            itemUri.toString()
        } catch (_: Exception) {
            runCatching { resolver.delete(itemUri, null, null) }
            saveViaAppMoviesDir(sourceFile, fileName)
        }
    }

    private fun saveViaAppMoviesDir(sourceFile: File, fileName: String): String {
        val moviesDir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
            ?: File(context.filesDir, "exports")
        val targetDir = File(moviesDir, "AutoClip").apply { mkdirs() }
        val destFile = File(targetDir, fileName)
        sourceFile.copyTo(destFile, overwrite = true)

        return runCatching {
            FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                destFile
            ).toString()
        }.getOrElse {
            Uri.fromFile(destFile).toString()
        }
    }

    private fun tryTakePersistablePermission(uri: Uri) {
        try {
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) {
            // Photo Picker URIs may not support persistable permissions; safe to ignore
        }
    }

    private fun inspectSingleUri(uri: Uri): MediaAsset? {
        val mime = context.contentResolver.getType(uri).orEmpty()
        val isVideo = mime.startsWith("video/")
        val isImage = mime.startsWith("image/")
        if (!isVideo && !isImage) return null

        val displayName = queryDisplayName(uri) ?: if (isVideo) "Video" else "Photo"
        val dateAdded = System.currentTimeMillis() / 1000L

        return if (isVideo) {
            var durationMs = 4_000L
            var width = 1080
            var height = 1920
            var hasAudio = false

            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, uri)
                durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull()?.coerceAtLeast(500L) ?: 4_000L
                val rawW = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                    ?.toIntOrNull() ?: 1080
                val rawH = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                    ?.toIntOrNull() ?: 1920
                val rot = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
                    ?.toIntOrNull() ?: 0
                hasAudio = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) == "yes"

                if (rot == 90 || rot == 270) {
                    width = rawH
                    height = rawW
                } else {
                    width = rawW
                    height = rawH
                }
            } catch (_: Exception) {
            } finally {
                runCatching { retriever.release() }
            }

            MediaAsset(
                id = UUID.randomUUID().toString(),
                uriString = uri.toString(),
                mediaType = MediaType.VIDEO,
                displayName = displayName,
                durationMs = durationMs,
                width = width,
                height = height,
                dateAddedSec = dateAdded,
                hasAudioTrack = hasAudio
            )
        } else {
            var width = 1080
            var height = 1920
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeStream(stream, null, options)
                    if (options.outWidth > 0 && options.outHeight > 0) {
                        width = options.outWidth
                        height = options.outHeight
                    }
                }
            } catch (_: Exception) {
            }

            MediaAsset(
                id = UUID.randomUUID().toString(),
                uriString = uri.toString(),
                mediaType = MediaType.PHOTO,
                displayName = displayName,
                durationMs = 0L,
                width = width,
                height = height,
                dateAddedSec = dateAdded,
                hasAudioTrack = false
            )
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) cursor.getString(idx) else null
                } else {
                    null
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun readHistoryFromDisk(): List<SavedVideoItem> {
        if (!historyFile.exists()) return emptyList()
        return runCatching {
            val array = JSONArray(historyFile.readText())
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    add(
                        SavedVideoItem(
                            id = obj.optString("id"),
                            uriString = obj.optString("uriString"),
                            displayName = obj.optString("displayName"),
                            durationMs = obj.optLong("durationMs"),
                            sizeBytes = obj.optLong("sizeBytes"),
                            createdAtMillis = obj.optLong("createdAtMillis"),
                            aspectLabel = obj.optString("aspectLabel", "9:16"),
                            promptSummary = obj.optString("promptSummary", "")
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun writeHistoryToDisk(items: List<SavedVideoItem>) {
        runCatching {
            val array = JSONArray()
            items.take(30).forEach { item ->
                array.put(
                    JSONObject().apply {
                        put("id", item.id)
                        put("uriString", item.uriString)
                        put("displayName", item.displayName)
                        put("durationMs", item.durationMs)
                        put("sizeBytes", item.sizeBytes)
                        put("createdAtMillis", item.createdAtMillis)
                        put("aspectLabel", item.aspectLabel)
                        put("promptSummary", item.promptSummary)
                    }
                )
            }
            historyFile.writeText(array.toString())
        }
    }
}
