package com.example

import com.example.data.model.AspectRatioPreset
import com.example.data.model.MediaAsset
import com.example.data.model.MediaType
import com.example.data.model.OrderingStrategy
import com.example.data.model.VisualStylePreset
import com.example.video_processing.FfmpegCommandBuilder
import com.example.video_processing.PromptDirector
import com.example.video_processing.StagedAsset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class PromptDirectorAndFfmpegTest {

    private fun sampleAssets(): List<MediaAsset> = listOf(
        MediaAsset(
            id = "p1",
            uriString = "content://media/1",
            mediaType = MediaType.PHOTO,
            displayName = "photo1.jpg",
            durationMs = 0L,
            width = 1080,
            height = 1920,
            dateAddedSec = 100L
        ),
        MediaAsset(
            id = "v1",
            uriString = "content://media/2",
            mediaType = MediaType.VIDEO,
            displayName = "clip1.mp4",
            durationMs = 5_000L,
            width = 1920,
            height = 1080,
            dateAddedSec = 200L,
            hasAudioTrack = true
        ),
        MediaAsset(
            id = "p2",
            uriString = "content://media/3",
            mediaType = MediaType.PHOTO,
            displayName = "photo2.jpg",
            durationMs = 0L,
            width = 1080,
            height = 1920,
            dateAddedSec = 300L
        )
    )

    @Test
    fun promptDirector_detectsLandscape16x9AndCinematicStyleFromArabicPrompt() {
        val plan = PromptDirector.buildPlan(
            prompt = "رحلة سفر سينمائية دافئة 16:9",
            aspectOverride = AspectRatioPreset.AUTO,
            assets = sampleAssets()
        )

        assertEquals(AspectRatioPreset.LANDSCAPE_16_9, plan.resolvedAspectRatio)
        assertEquals(1920, plan.resolvedAspectRatio.targetWidth)
        assertEquals(1080, plan.resolvedAspectRatio.targetHeight)
        assertEquals(VisualStylePreset.CINEMATIC_WARM, plan.stylePreset)
        assertEquals(OrderingStrategy.CHRONOLOGICAL, plan.orderingStrategy)
    }

    @Test
    fun promptDirector_usesHookAndFlowForMixedMediaReels() {
        val plan = PromptDirector.buildPlan(
            prompt = "إعلان سريع وحيوي 9:16",
            aspectOverride = AspectRatioPreset.AUTO,
            assets = sampleAssets()
        )

        assertEquals(AspectRatioPreset.PORTRAIT_9_16, plan.resolvedAspectRatio)
        assertEquals(VisualStylePreset.VIVID_POP, plan.stylePreset)
        assertEquals(OrderingStrategy.HOOK_AND_FLOW, plan.orderingStrategy)
        assertEquals(MediaType.VIDEO, plan.orderedAssets.first().mediaType)
    }

    @Test
    fun ffmpegCommandBuilder_generatesUnifiedScaleCropAndConcatArgs() {
        val assets = sampleAssets()
        val plan = PromptDirector.buildPlan(
            prompt = "فيديو ريلز 9:16",
            aspectOverride = AspectRatioPreset.PORTRAIT_9_16,
            assets = assets
        )
        val staged = plan.orderedAssets.mapIndexed { idx, asset ->
            StagedAsset(asset, File("/tmp/input_$idx.dat"))
        }

        val args = FfmpegCommandBuilder.buildArguments(
            plan = plan,
            stagedAssets = staged,
            titleOverlayPng = File("/tmp/title.png"),
            watermarkOverlayPng = File("/tmp/watermark.png"),
            backgroundAudioFile = null,
            outputFile = File("/tmp/output.mp4")
        ).toList()

        val filterComplexIdx = args.indexOf("-filter_complex")
        assertTrue(filterComplexIdx >= 0)
        val filterGraph = args[filterComplexIdx + 1]
        assertTrue(filterGraph.contains("scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920"))
        assertTrue(filterGraph.contains("concat=n=3:v=1:a=1"))
        assertTrue(args.contains("libx264"))
        assertEquals("/tmp/output.mp4", args.last())
    }
}
