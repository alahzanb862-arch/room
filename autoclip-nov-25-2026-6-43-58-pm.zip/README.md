# AutoClip — استوديو المونتاج التلقائي (Android Kotlin + FFmpegKit)

تطبيق أندرويد متكامل ومفتوح المصدر مبني بلغة **Kotlin** و **Jetpack Compose** وفق معمارية **MVVM** لإنشاء ودمج الصور والفيديوهات تلقائياً بالكامل على الجهاز، مجاني 100% وبدون أي اشتراكات أو خدمات سحابية مدفوعة.

---

## المميزات الرئيسية

- **اختيار وسائط بدون أذونات تخزين حساسة**: استخدام **Android Photo Picker** (`PickMultipleVisualMedia`) لاختيار صور وفيديوهات متعددة، مع دعم اختيار موسيقى خلفية اختيارية عبر `OpenDocument`.
- **توجيه ذكي للفكرة والمقاس (`PromptDirector`)**: تحليل فوري لنص الفكرة (عربي/إنجليزي) لاختيار:
  - المقاس الموحد: `9:16` (`1080×1920`) أو `16:9` (`1920×1080`).
  - استراتيجية ترتيب الوسائط (افتتاحية فيديو + تناوب ذكي، تسلسل زمني، أو تمهيد بالصور).
  - الفلتر اللوني وإيقاع العرض.
  - استخراج عنوان افتتاحي واضح يظهر فوق الفيديو بدقة عالية للغة العربية (`RTL StaticLayout` -> PNG Overlay).
- **معالجة ودمج عبر FFmpegKit**: توحيد أبعاد جميع الصور والفيديوهات (`scale` + `crop` + `30fps` + `yuv420p`)، إضافة النصوص والفلاتر، ودمج الصوت تلقائياً.
- **تشغيل في الخلفية مع شريط تقدم (`WorkManager` + `ForegroundService`)**: متابعة نسبة الإنجاز لحظياً داخل التطبيق وفي إشعار النظام، مع إمكانية الإلغاء في أي وقت.
- **حفظ تلقائي في المعرض**: حفظ ملف `.mp4` النهائي مباشرة في مجلد `Movies/AutoClip` عبر `MediaStore` مع مشغل معاينة مدمج (`Media3 ExoPlayer`) وزر مشاركة فوري.

---

## هيكل المشروع (MVVM Architecture)

```text
app/src/main/java/com/example/
├── MainActivity.kt
├── data/
│   ├── model/                  # نماذج البيانات وحالة المهام (MediaAsset, AutoRenderPlan, RenderJobState, ...)
│   └── repository/             # MediaRepository (فحص الوسائط، تجهيز الملفات، الحفظ عبر MediaStore، السجل)
├── video_processing/
│   ├── PromptDirector.kt       # محرك تحليل الوصف/البرومبت وتخطيط المونتاج تلقائياً
│   ├── OverlayBitmapFactory.kt # توليد ملصقات النصوص العربية/الإنجليزية (RTL-safe PNG)
│   ├── FfmpegCommandBuilder.kt # بناء أوامر FFmpeg لتوحيد الأبعاد والدمج والفلاتر
│   ├── FFmpegVideoProcessor.kt # تنفيذ FFmpegKit مع تتبع التقدم وإمكانية الإلغاء
│   ├── AutoVideoExportWorker.kt# WorkManager CoroutineWorker للعمل في الخلفية
│   └── ExportCoordinator.kt    # إدارة مهام الخلفية ومراقبة حالتها
└── ui/
    ├── theme/                  # Material 3 Theme، الألوان، والخطوط المدمجة (Cairo + Space Grotesk)
    ├── viewmodel/              # StudioViewModel لإدارة الحالة والتدفقات (StateFlow)
    ├── components/             # مكونات Compose المعيارية
    └── screens/                # StudioScreen المتجاوبة مع الهواتف والأجهزة اللوحية
```

---

## الاعتمادات الأساسية

- **Jetpack Compose & Material 3**
- **FFmpegKit (`dev.ffmpegkit-maintained:ffmpeg-kit-full-gpl`)** لمعالجة الفيديو والصوت والصور محلياً
- **AndroidX WorkManager** لتنفيذ الدمج في الخلفية بأمان
- **Jetpack Media3 ExoPlayer** لمعاينة الفيديوهات الناتجة داخل التطبيق
- **Coil & Coil-Video** لعرض معاينات الصور وإطارات الفيديو

---

## البناء التلقائي عبر GitHub Actions (CI/CD)

يتضمن المستودع ملف `.github/workflows/android-ci.yml` الذي يعمل تلقائياً عند كل `push` أو `pull_request` أو تشغيل يدوي (`workflow_dispatch`):

1. فك ترميز مفتاح التوقيع التجريبي `debug.keystore` من `debug.keystore.base64`.
2. تشغيل اختبارات الوحدة: `gradle :app:testDebugUnitTest`.
3. تجميع ملف التطبيق: `gradle :app:assembleDebug`.
4. رفع ملف الـ APK النهائي كـ Artifact باسم **`autoclip-debug-apk`** جاهز للتحميل من تبويب **Actions** في GitHub.

### البناء محلياً

```bash
# تشغيل الاختبارات
gradle :app:testDebugUnitTest

# بناء ملف APK
gradle :app:assembleDebug
```

ستجد ملف الـ APK الناتج في المسار:
`app/build/outputs/apk/debug/app-debug.apk`
